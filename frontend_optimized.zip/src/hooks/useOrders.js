import { orderAPI } from '../services/api';

export default function useOrders() {
  const list = async () => (await orderAPI.getMyOrders()).data;
  const cancel = async (orderId) => (await orderAPI.cancelOrder(orderId)).data;
  const requestReturn = async (orderId, reason) => (await orderAPI.requestReturn(orderId, reason)).data;
  return { list, cancel, requestReturn };
}
