import { useCart } from '../context/CartContext';
export default useCart;
