import { AuthProvider } from './AuthContext';
import { CartProvider } from './CartContext';

export default function AppContext({ children }) {
  return (
    <AuthProvider>
      <CartProvider>{children}</CartProvider>
    </AuthProvider>
  );
}

export { AuthProvider } from './AuthContext';
export { CartProvider } from './CartContext';
export { useAuth } from './AuthContext';
export { useCart } from './CartContext';
