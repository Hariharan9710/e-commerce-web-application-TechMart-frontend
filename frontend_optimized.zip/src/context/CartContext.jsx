import { createContext, useContext, useEffect, useState } from 'react';
import { cartAPI } from '../services/api';
import { useAuth } from './AuthContext';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const { user } = useAuth();
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    // Load when user changes
    if (user?.email) {
      loadCartFromBackend(user.email);
    } else {
      loadLocalCart();
    }
  }, [user?.email]);

  const loadCartFromBackend = async (email) => {
    try {
      const response = await cartAPI.getCart(email);
      const items = (response.data || []).map(item => ({
        ...item,
        image: item.image?.startsWith('http') ? item.image : `http://localhost:8080/images/${item.image}`
      }));
      setCartItems(items);
      localStorage.removeItem('localCart');
    } catch (e) {
      console.error('Cart load failed', e);
    }
  };

  const loadLocalCart = () => {
    try {
      const local = JSON.parse(localStorage.getItem('localCart') || '[]');
      setCartItems(local);
    } catch {
      setCartItems([]);
    }
  };

  const saveLocalCart = (items) => {
    localStorage.setItem('localCart', JSON.stringify(items));
  };

  const addToCart = async (product, quantity = 1) => {
    if (!user?.email) {
      // Save pending action for after login
      const items = [...cartItems];
      const idx = items.findIndex(i => i.id === product.id);
      if (idx >= 0) items[idx].quantity += quantity;
      else items.push({ ...product, quantity });
      setCartItems(items);
      saveLocalCart(items);
      return { local: true };
    }
    await cartAPI.addToCart(user.email, product.id, quantity);
    await loadCartFromBackend(user.email);
  };

  const updateQuantity = async (cartItemId, nextQty) => {
    if (!user?.email) {
      const items = cartItems.map(i => i.id === cartItemId ? { ...i, quantity: nextQty } : i).filter(i => i.quantity > 0);
      setCartItems(items);
      saveLocalCart(items);
      return;
    }
    if (nextQty < 1) return removeItem(cartItemId);
    await cartAPI.updateCart(user.email, cartItemId, nextQty);
    await loadCartFromBackend(user.email);
  };

  const removeItem = async (cartItemId) => {
    if (!user?.email) {
      const items = cartItems.filter(i => i.id !== cartItemId);
      setCartItems(items);
      saveLocalCart(items);
      return;
    }
    await cartAPI.removeFromCart(user.email, cartItemId);
    await loadCartFromBackend(user.email);
  };

  const mergeLocalToBackend = async () => {
    if (!user?.email) return;
    try {
      const local = JSON.parse(localStorage.getItem('localCart') || '[]');
      if (local.length) {
        await cartAPI.mergeCart(user.email, local);
        localStorage.removeItem('localCart');
      }
      await loadCartFromBackend(user.email);
    } catch (e) {
      console.error('Merge cart failed', e);
    }
  };

  const value = { cartItems, addToCart, updateQuantity, removeItem, loadCart: () => user?.email ? loadCartFromBackend(user.email) : loadLocalCart(), mergeLocalToBackend };
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
export default CartContext;
