// Adapter to support both 'services' and 'Services' import paths
export * from '../Services/api';
