import { useState, useEffect } from 'react';
import { Package, CheckCircle, XCircle, ArrowLeft, AlertCircle } from 'lucide-react';
import { adminAPI } from '../services/api';
import { formatPrice } from '../utils/helpers';

export default function AdminReturnManagement({ navigate }) {
  const [returns, setReturns] = useState([]);
  const [loading, setLoading] = useState(true);

  // ✅ Modal States
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState(''); // 'reject' | 'condition'
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [modalInput, setModalInput] = useState('');

  useEffect(() => {
    loadReturns();
  }, []);

  const loadReturns = async () => {
    try {
      const response = await adminAPI.getAllReturnRequests();
      setReturns(response.data);
    } catch (error) {
      console.error('Error loading returns:', error);
      alert('Failed to load returns');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (orderId) => {
    if (!window.confirm('Approve this return request? Customer will be notified to ship the product back.')) return;
    try {
      await adminAPI.approveReturn(orderId);
      alert('✅ Return approved! Customer notified to ship product.');
      loadReturns();
    } catch (error) {
      alert('Failed to approve return');
    }
  };

  // ✅ NEW REPLACED REJECT BUTTON → Opens Modal
  const handleReject = (orderId) => {
    setSelectedOrderId(orderId);
    setModalType('reject');
    setModalInput('');
    setShowModal(true);
  };

  const confirmReject = async () => {
    if (!modalInput.trim()) {
      alert('Please enter a reason');
      return;
    }
    try {
      await adminAPI.rejectReturn(selectedOrderId, modalInput);
      alert('❌ Return rejected');
      setShowModal(false);
      loadReturns();
    } catch (error) {
      alert('Failed to reject return');
    }
  };

  // ✅ NEW REPLACED PRODUCT RECEIVED BUTTON → Opens Modal
  const handleReturnReceived = (orderId) => {
    setSelectedOrderId(orderId);
    setModalType('condition');
    setShowModal(true);
  };

  const confirmCondition = async (condition) => {
    try {
      await adminAPI.confirmReturnReceived(selectedOrderId, condition);
      alert(condition === 'GOOD' ? '✅ Return accepted' : '❌ Return rejected due to condition');
      setShowModal(false);
      loadReturns();
    } catch (error) {
      alert('Failed to update status');
    }
  };

  const handleInitiateRefund = async (orderId) => {
    if (!window.confirm('Initiate refund process?')) return;
    try {
      await adminAPI.initiateRefund(orderId);
      alert('✅ Refund initiated! Stock has been restored.');
      loadReturns();
    } catch (error) {
      alert('Failed to initiate refund');
    }
  };

  const handleCompleteRefund = async (orderId) => {
    if (!window.confirm('Confirm refund is completed?')) return;
    try {
      await adminAPI.completeRefund(orderId);
      alert('✅ Refund completed successfully!');
      loadReturns();
    } catch (error) {
      alert('Failed to complete refund');
    }
  };

  const isEligibleFor15Days = (deliveredAt) => {
    if (!deliveredAt) return false;
    const delivered = new Date(deliveredAt);
    const fifteenDaysAgo = new Date();
    fifteenDaysAgo.setDate(fifteenDaysAgo.getDate() - 15);
    return delivered >= fifteenDaysAgo;
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      'REQUESTED': { color: 'bg-yellow-100 text-yellow-800', text: '⏳ Awaiting Approval' },
      'APPROVED': { color: 'bg-blue-100 text-blue-800', text: '📦 Awaiting Product' },
      'REJECTED': { color: 'bg-red-100 text-red-800', text: '❌ Rejected' },
      'RETURN_RECEIVED': { color: 'bg-purple-100 text-purple-800', text: '✅ Product Received' },
      'REFUND_INITIATED': { color: 'bg-orange-100 text-orange-800', text: '💰 Refund Processing' },
      'REFUND_COMPLETED': { color: 'bg-green-100 text-green-800', text: '✅ Refund Complete' },
      'RETURN_REJECTED': { color: 'bg-red-100 text-red-800', text: '❌ Return Rejected' }
    };
    const config = statusConfig[status] || { color: 'bg-gray-100 text-gray-800', text: status };
    return <span className={`px-3 py-1 rounded-full text-sm font-medium ${config.color}`}>{config.text}</span>;
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">

      {/* ✅ MODAL POPUP */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full shadow-lg">
            <h3 className="text-xl font-bold mb-4">
              {modalType === 'reject' ? 'Rejection Reason' : 'Product Condition Check'}
            </h3>

            {modalType === 'reject' ? (
              <>
                <textarea
                  value={modalInput}
                  onChange={(e) => setModalInput(e.target.value)}
                  placeholder="Enter rejection reason..."
                  className="w-full border rounded p-3 mb-4"
                  rows="4"
                />
                <div className="flex gap-3">
                  <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                  <button onClick={confirmReject} className="px-4 py-2 bg-red-600 text-white rounded">Submit</button>
                </div>
              </>
            ) : (
              <>
                <p className="mb-4">Is the product in good condition?</p>
                <div className="space-y-2 mb-4">
                  <p>✅ Good: Undamaged, complete, resalable</p>
                  <p>❌ Damaged: Broken, dirty, modified</p>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => confirmCondition('DAMAGED')} className="px-4 py-2 bg-red-600 text-white rounded">Damaged</button>
                  <button onClick={() => confirmCondition('GOOD')} className="px-4 py-2 bg-green-600 text-white rounded">Good Condition</button>
                  <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ORIGINAL UI BELOW — UNTOUCHED */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <button onClick={() => navigate('/admin-dashboard')} className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-4 font-medium">
          <ArrowLeft className="w-5 h-5" /> Back to Dashboard
        </button>

        <h1 className="text-3xl font-bold mb-2">Return Requests Management</h1>

        {returns.length === 0 ? (
          <div>No return requests</div>
        ) : (
          returns.map((order) => (
            <div key={order.id} className="bg-white rounded-lg shadow-md p-6 mb-4">
              {/* SAME UI — NO CHANGE */}
              <div className="flex justify-between mb-4">
                <div>
                  <h3 className="font-bold">Order #{order.id}</h3>
                  <p>{order.user.email}</p>
                </div>
                {getStatusBadge(order.returnStatus)}
              </div>

              {order.returnStatus === 'REQUESTED' && (
                <div className="flex gap-3">
                  <button onClick={() => handleApprove(order.id)} className="bg-green-600 text-white px-4 py-2 rounded">Approve</button>
                  <button onClick={() => handleReject(order.id)} className="bg-red-600 text-white px-4 py-2 rounded">Reject</button>
                </div>
              )}

              {order.returnStatus === 'APPROVED' && (
                <button onClick={() => handleReturnReceived(order.id)} className="bg-blue-600 text-white w-full py-2 rounded">
                  Product Received - Check Condition
                </button>
              )}

              {order.returnStatus === 'RETURN_RECEIVED' && (
                <button onClick={() => handleInitiateRefund(order.id)} className="bg-orange-600 text-white w-full py-2 rounded">
                  Initiate Refund
                </button>
              )}

              {order.returnStatus === 'REFUND_INITIATED' && (
                <button onClick={() => handleCompleteRefund(order.id)} className="bg-green-600 text-white w-full py-2 rounded">
                  Complete Refund
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}