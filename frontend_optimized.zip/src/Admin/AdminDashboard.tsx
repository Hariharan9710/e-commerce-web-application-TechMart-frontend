import { useState, useEffect } from 'react';
import {
  ShoppingCart, Package, Users, DollarSign, TrendingUp,
  Plus, LogOut
} from 'lucide-react';
import { adminAPI } from '../services/api';
import { formatPrice } from '../utils/helpers';

export default function AdminDashboard({ navigate, logout, user }) {
  const [dashboardData, setDashboardData] = useState(null);
  const [stockSummary, setStockSummary] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [dashResponse, stockResponse] = await Promise.all([
        adminAPI.getDashboard(),
        adminAPI.getStockSummary()
      ]);
      setDashboardData(dashResponse.data);
      setStockSummary(stockResponse.data);
    } catch (error) {
      console.error('Error loading dashboard:', error);
      alert('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-8 h-8 text-blue-600" />
            <div>
              <span className="text-2xl font-bold text-blue-600">TechMart</span>
              <span className="ml-2 text-sm bg-blue-100 text-blue-600 px-2 py-1 rounded">Admin</span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-semibold">{user?.firstName} {user?.lastName}</p>
              <p className="text-sm text-gray-600">Administrator</p>
            </div>
            <button
              onClick={logout}
              className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">Manage your store inventory and monitor sales</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-blue-100 p-3 rounded-lg">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <h3 className="text-gray-600 text-sm mb-1">Total Products</h3>
            <p className="text-3xl font-bold">{dashboardData?.totalProducts || 0}</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-green-100 p-3 rounded-lg">
                <ShoppingCart className="w-6 h-6 text-green-600" />
              </div>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <h3 className="text-gray-600 text-sm mb-1">Total Orders</h3>
            <p className="text-3xl font-bold">{dashboardData?.totalOrders || 0}</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-purple-100 p-3 rounded-lg">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <h3 className="text-gray-600 text-sm mb-1">Total Users</h3>
            <p className="text-3xl font-bold">{dashboardData?.totalUsers || 0}</p>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-yellow-100 p-3 rounded-lg">
                <DollarSign className="w-6 h-6 text-yellow-600" />
              </div>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <h3 className="text-gray-600 text-sm mb-1">Total Revenue</h3>
            <p className="text-3xl font-bold">{formatPrice(dashboardData?.totalRevenue || 0)}</p>
          </div>
        </div>

        {/* ✅ ✅ NEW BUTTONS SECTION */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <button
            onClick={() => navigate('/admin-orders')}
            className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition"
          >
            <Package className="w-8 h-8 text-blue-600 mb-2" />
            <h3 className="font-bold text-lg">Manage Orders</h3>
            <p className="text-gray-600 text-sm">View and update order status</p>
          </button>

          {/* ✅ ADDED RETURN REQUESTS BUTTON */}
          <button
            onClick={() => navigate('/admin-returns')}
            className="bg-white p-6 rounded-lg shadow hover:shadow-lg transition"
          >
            <Package className="w-8 h-8 text-orange-600 mb-2" />
            <h3 className="font-bold text-lg">Return Requests</h3>
            <p className="text-gray-600 text-sm">Review and process returns</p>
          </button>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-md mb-6">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('overview')}
              className={`px-6 py-3 font-medium ${activeTab === 'overview'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600 hover:text-gray-900'}`}
            >
              Stock Overview
            </button>
            <button
              onClick={() => setActiveTab('products')}
              className={`px-6 py-3 font-medium ${activeTab === 'products'
                ? 'border-b-2 border-blue-600 text-blue-600'
                : 'text-gray-600 hover:text-gray-900'}`}
            >
              Product Management
            </button>
          </div>
        </div>

        {/* Stock Overview */}
        {activeTab === 'overview' && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-2xl font-bold mb-6">Stock Summary by Category</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {stockSummary.map((category) => (
                <div key={category.category} className="border border-gray-200 rounded-lg p-6">
                  <h3 className="text-lg font-bold mb-4">{category.category}</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Stock:</span>
                      <span className="font-semibold text-xl">{category.totalStock}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Products:</span>
                      <span className="font-semibold">{category.productCount}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => navigate('/admin-products', { category: category.category })}
                    className="mt-4 w-full bg-blue-50 text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-100 transition font-medium"
                  >
                    View Details
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Product Management */}
        {activeTab === 'products' && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Product Management</h2>
              <button
                onClick={() => navigate('/admin-add-product')}
                className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition"
              >
                <Plus className="w-5 h-5" />
                Add New Product
              </button>
            </div>
            <p className="text-gray-600 mb-4">
              Click "Add New Product" to create a new product or manage existing products by category.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {stockSummary.map((category) => (
                <button
                  key={category.category}
                  onClick={() => navigate('/admin-products', { category: category.category })}
                  className="border-2 border-gray-200 rounded-lg p-6 hover:border-blue-600 hover:bg-blue-50 transition text-left"
                >
                  <h3 className="text-lg font-bold mb-2">{category.category}</h3>
                  <p className="text-sm text-gray-600">{category.productCount} products</p>
                </button>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}