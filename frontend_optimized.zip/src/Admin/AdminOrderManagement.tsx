// import { useState, useEffect } from 'react';
// import { Package, CheckCircle } from 'lucide-react';
// import { adminAPI } from '../services/api';
// import { formatPrice } from '../utils/helpers';

// export default function AdminOrderManagement() {
//   const [orders, setOrders] = useState([]);
//   const [loading, setLoading] = useState(true);

//   // ✅ NEW: Filter state
//   const [filter, setFilter] = useState('all'); // all | active | refunded

//   useEffect(() => {
//     loadOrders();
//   }, []);

//   const loadOrders = async () => {
//     try {
//       const response = await adminAPI.getAllOrders();
//       setOrders(response.data);
//     } catch (error) {
//       console.error('Error loading orders:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleConfirmPayment = async (orderId) => {
//     if (!window.confirm('Confirm payment for this order?')) return;
    
//     try {
//       await adminAPI.confirmPayment(orderId);
//       alert('Payment confirmed!');
//       loadOrders();
//     } catch (error) {
//       alert('Failed to confirm payment');
//     }
//   };

//   const handleUpdateStatus = async (orderId, newStatus) => {
//     let trackingNumber = null;
//     if (newStatus === 'SHIPPED') {
//       trackingNumber = prompt('Enter tracking number:');
//       if (!trackingNumber) return;
//     }
    
//     try {
//       await adminAPI.updateOrderStatus(orderId, newStatus, trackingNumber);
//       alert('Status updated!');
//       loadOrders();
//     } catch (error) {
//       alert('Failed to update status');
//     }
//   };

//   const STATUS_OPTIONS = [
//     'PAYMENT_CONFIRMED',
//     'PROCESSING',
//     'SHIPPED',
//     'OUT_FOR_DELIVERY',
//     'DELIVERED'
//   ];

//   // ✅ NEW: Filtered orders
//   const filteredOrders = orders.filter(order => {
//     if (filter === 'refunded') return order.returnStatus === 'REFUND_COMPLETED';
//     if (filter === 'active') return order.returnStatus !== 'REFUND_COMPLETED';
//     return true;
//   });

//   return (
//     <div className="p-6">
//       <h2 className="text-2xl font-bold mb-6">Order Management</h2>

//       {/* ✅ NEW FILTER TABS */}
//       <div className="flex gap-4 mb-6">
//         <button
//           onClick={() => setFilter('all')}
//           className={`px-4 py-2 rounded ${filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
//         >
//           All Orders
//         </button>
//         <button
//           onClick={() => setFilter('active')}
//           className={`px-4 py-2 rounded ${filter === 'active' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
//         >
//           Active Orders
//         </button>
//         <button
//           onClick={() => setFilter('refunded')}
//           className={`px-4 py-2 rounded ${filter === 'refunded' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
//         >
//           Refunded Orders
//         </button>
//       </div>

//       {loading ? (
//         <div>Loading orders...</div>
//       ) : (
//         <div className="space-y-4">
//           {filteredOrders.map((order) => (
//             <div key={order.id} className="bg-white rounded-lg shadow p-6">

//               <div className="flex justify-between items-start mb-4">
//                 <div>
//                   <h3 className="text-lg font-bold">Order #{order.id}</h3>
//                   <p className="text-sm text-gray-600">
//                     Customer: {order.user.firstName} {order.user.lastName}
//                   </p>
//                   <p className="text-sm text-gray-600">{order.user.email}</p>
//                   <p className="text-sm text-gray-600">
//                     {new Date(order.orderDate).toLocaleString()}
//                   </p>
//                 </div>
//                 <div className="text-right">
//                   <span className="font-bold text-blue-600">{formatPrice(order.totalAmount)}</span>

//                   {/* ✅ NEW: Show refunded amount */}
//                   {order.refundedAmount > 0 && (
//                     <p className="text-red-600 font-bold">
//                       Refunded: {formatPrice(order.refundedAmount)}
//                     </p>
//                   )}

//                   <p className="text-sm text-gray-600">Payment: {order.paymentMethod}</p>
//                   <p className={`text-sm font-medium ${order.paymentStatus === 'CONFIRMED' ? 'text-green-600' : 'text-yellow-600'}`}>
//                     {order.paymentStatus}
//                   </p>
//                 </div>
//               </div>

//               <div className="border-t border-gray-200 pt-4 mb-4">
//                 <p className="text-sm"><strong>Status:</strong> {order.status}</p>
//                 <p className="text-sm"><strong>Address:</strong> {order.shippingAddress}</p>
//                 {order.trackingNumber && (
//                   <p className="text-sm"><strong>Tracking:</strong> {order.trackingNumber}</p>
//                 )}
//               </div>

//               <div className="flex gap-2">
//                 {order.paymentMethod !== 'Cash on Delivery' && 
//                  order.paymentStatus === 'PENDING' && (
//                   <button onClick={() => handleConfirmPayment(order.id)}>
//                     Confirm Payment
//                   </button>
//                 )}

//                 {((order.paymentMethod === 'Cash on Delivery') || 
//                   (order.paymentStatus === 'CONFIRMED')) && 
//                  order.status !== 'DELIVERED' && 
//                  order.status !== 'CANCELLED' && (
//                   <select onChange={(e) => handleUpdateStatus(order.id, e.target.value)}>
//                     <option value="">Update Status...</option>
//                     {STATUS_OPTIONS.map((status) => (
//                       <option key={status} value={status}>{status}</option>
//                     ))}
//                   </select>
//                 )}

//                 {order.paymentMethod === 'Cash on Delivery' && 
//                  order.status === 'DELIVERED' && 
//                  order.paymentStatus === 'PENDING' && (
//                   <button onClick={() => handleConfirmPayment(order.id)}>
//                     Confirm COD Payment Received
//                   </button>
//                 )}
//               </div>

//             </div>
//           ))}
//         </div>
//       )}
//     </div>
//   );
// }


import { useState, useEffect } from 'react';
import { Package, CheckCircle } from 'lucide-react';
import { adminAPI } from '../services/api';
import { formatPrice } from '../utils/helpers';

export default function AdminOrderManagement() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  // ✅ Filter state
  const [filter, setFilter] = useState('all'); // all | active | refunded

  useEffect(() => {
    loadOrders();
  }, []);

  const loadOrders = async () => {
    try {
      const response = await adminAPI.getAllOrders();
      setOrders(response.data);
    } catch (error) {
      console.error('Error loading orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmPayment = async (orderId) => {
    if (!window.confirm('Confirm payment for this order?')) return;
    
    try {
      await adminAPI.confirmPayment(orderId);
      alert('Payment confirmed!');
      loadOrders();
    } catch (error) {
      alert('Failed to confirm payment');
    }
  };

  const handleUpdateStatus = async (orderId, newStatus) => {
    let trackingNumber = null;
    if (newStatus === 'SHIPPED') {
      trackingNumber = prompt('Enter tracking number:');
      if (!trackingNumber) return;
    }
    
    try {
      await adminAPI.updateOrderStatus(orderId, newStatus, trackingNumber);
      alert('Status updated!');
      loadOrders();
    } catch (error) {
      alert('Failed to update status');
    }
  };

  const STATUS_OPTIONS = [
    'PAYMENT_CONFIRMED',
    'PROCESSING',
    'SHIPPED',
    'OUT_FOR_DELIVERY',
    'DELIVERED'
  ];

  // ✅ UPDATED: Correct Active Orders Filter
  const filteredOrders = orders.filter(order => {
    if (filter === 'refunded')
      return order.returnStatus === 'REFUND_COMPLETED';

    if (filter === 'active')
      return (
        order.status !== 'DELIVERED' &&
        order.status !== 'CANCELLED' &&
        order.returnStatus !== 'REFUND_COMPLETED'
      );

    return true; // all
  });

  return (
    <div className="p-6">
      <h2 className="text-2xl font-bold mb-6">Order Management</h2>

      {/* ✅ FILTER TABS */}
      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setFilter('all')}
          className={`px-4 py-2 rounded ${filter === 'all' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
        >
          All Orders
        </button>
        <button
          onClick={() => setFilter('active')}
          className={`px-4 py-2 rounded ${filter === 'active' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
        >
          Active Orders
        </button>
        <button
          onClick={() => setFilter('refunded')}
          className={`px-4 py-2 rounded ${filter === 'refunded' ? 'bg-blue-600 text-white' : 'bg-gray-200'}`}
        >
          Refunded Orders
        </button>
      </div>

      {loading ? (
        <div>Loading orders...</div>
      ) : (
        <div className="space-y-4">
          {filteredOrders.map((order) => (
            <div key={order.id} className="bg-white rounded-lg shadow p-6">

              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-lg font-bold">Order #{order.id}</h3>
                  <p className="text-sm text-gray-600">
                    Customer: {order.user.firstName} {order.user.lastName}
                  </p>
                  <p className="text-sm text-gray-600">{order.user.email}</p>
                  <p className="text-sm text-gray-600">
                    {new Date(order.orderDate).toLocaleString()}
                  </p>
                </div>
                <div className="text-right">
                  <span className="font-bold text-blue-600">{formatPrice(order.totalAmount)}</span>

                  {/* ✅ Show refunded amount */}
                  {order.refundedAmount > 0 && (
                    <p className="text-red-600 font-bold">
                      Refunded: {formatPrice(order.refundedAmount)}
                    </p>
                  )}

                  <p className="text-sm text-gray-600">Payment: {order.paymentMethod}</p>
                  <p className={`text-sm font-medium ${order.paymentStatus === 'CONFIRMED' ? 'text-green-600' : 'text-yellow-600'}`}>
                    {order.paymentStatus}
                  </p>
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4 mb-4">
                <p className="text-sm"><strong>Status:</strong> {order.status}</p>
                <p className="text-sm"><strong>Address:</strong> {order.shippingAddress}</p>
                {order.trackingNumber && (
                  <p className="text-sm"><strong>Tracking:</strong> {order.trackingNumber}</p>
                )}
              </div>

              {/* ACTION BUTTONS - NO CHANGE */}
              <div className="flex gap-2">
                {order.paymentMethod !== 'Cash on Delivery' && 
                 order.paymentStatus === 'PENDING' && (
                  <button onClick={() => handleConfirmPayment(order.id)}>
                    Confirm Payment
                  </button>
                )}

                {((order.paymentMethod === 'Cash on Delivery') || 
                  (order.paymentStatus === 'CONFIRMED')) && 
                 order.status !== 'DELIVERED' && 
                 order.status !== 'CANCELLED' && (
                  <select onChange={(e) => handleUpdateStatus(order.id, e.target.value)}>
                    <option value="">Update Status...</option>
                    {STATUS_OPTIONS.map((status) => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                )}

                {order.paymentMethod === 'Cash on Delivery' && 
                 order.status === 'DELIVERED' && 
                 order.paymentStatus === 'PENDING' && (
                  <button onClick={() => handleConfirmPayment(order.id)}>
                    Confirm COD Payment Received
                  </button>
                )}
              </div>

            </div>
          ))}
        </div>
      )}
    </div>
  );
}
