import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './Pages/HomePage';
import LoginPage from './Pages/LoginPage';
import RegisterPage from './Pages/RegisterPage';
import AllProductsPage from './Pages/AllProductsPage';
import CategoryProductsPage from './Pages/CategoryProductsPage';
import ProductDetailPage from './Pages/ProductDetailPage';
import ShoppingCartPage from './Pages/ShoppingCartPage';
import CheckoutPage from './Pages/CheckoutPage';
import ProfilePage from './Pages/ProfilePage';
import CustomerHelpPage from './Pages/CustomerHelpPage';
import OrderHistoryPage from './Pages/OrderHistoryPage';

import AdminLoginPage from './Admin/AdminLoginPage';
import AdminDashboard from './Admin/AdminDashboard';
import AdminProductManagement from './Admin/AdminProductManagement';
import AdminOrderManagement from './Admin/AdminOrderManagement';
import AdminReturnManagement from './Admin/AdminReturnManagement';

import AppContext from './context/AppContext';
import PrivateRoute from './Components/PrivateRoute';
import AdminRoute from './Components/AdminRoute';

export default function App() {
  const publicRoutes = [
    { path: '/', Component: HomePage },
    { path: '/login', Component: LoginPage },
    { path: '/register', Component: RegisterPage },
    { path: '/all-products', Component: AllProductsPage },
    { path: '/category/products', Component: CategoryProductsPage },
    { path: '/product-detail', Component: ProductDetailPage },
    { path: '/customer-help', Component: CustomerHelpPage },
  ];

  const userRoutes = [
    { path: '/cart', Component: ShoppingCartPage },
    { path: '/checkout', Component: CheckoutPage },
    { path: '/profile', Component: ProfilePage },
    { path: '/orders', Component: OrderHistoryPage },
  ];

  const adminRoutes = [
    { path: '/admin-login', Component: AdminLoginPage },
    { path: '/admin-dashboard', Component: AdminDashboard },
    { path: '/admin-products', Component: AdminProductManagement },
    { path: '/admin-orders', Component: AdminOrderManagement },
    { path: '/admin-returns', Component: AdminReturnManagement },
  ];

  return (
    <AppContext>
      <Router>
        <Routes>
          {publicRoutes.map(({ path, Component }) => (
            <Route key={path} path={path} element={<Component />} />
          ))}

          {userRoutes.map(({ path, Component }) => (
            <Route key={path} path={path} element={<PrivateRoute><Component /></PrivateRoute>} />
          ))}

          {adminRoutes.map(({ path, Component }) => (
            <Route
              key={path}
              path={path}
              element={path === '/admin-login' ? <Component /> : <AdminRoute><Component /></AdminRoute>}
            />
          ))}

          <Route path="*" element={<HomePage />} />
        </Routes>
      </Router>
    </AppContext>
  );
}
