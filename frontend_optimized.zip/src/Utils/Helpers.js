// Shared utility functions
export const formatPrice = (price) => `₹${(price ?? 0).toLocaleString('en-IN')}`;

export const calculateSubtotal = (cartItems) => {
  return cartItems.reduce((sum, item) => 
    sum + ((item.price || 0) * (item.quantity || 0)), 0
  );
};

export const calculateTax = (subtotal, rate = 0.18) => {
  return subtotal * rate;
};

export const calculateTotal = (cartItems) => {
  const subtotal = calculateSubtotal(cartItems);
  return subtotal + calculateTax(subtotal);
};

export const getTotalQuantity = (cartItems) => {
  if (!cartItems || cartItems.length === 0) return 0;
  return cartItems.reduce((sum, item) => sum + (item.quantity || 0), 0);
};

export const getCartTotals = (cartItems, taxRate = 0.18) => {
  const subtotal = calculateSubtotal(cartItems);
  const tax = calculateTax(subtotal, taxRate);
  const total = subtotal + tax;
  return { subtotal, tax, total };
};
