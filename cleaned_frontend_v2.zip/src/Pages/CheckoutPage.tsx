import Header from '../components/Header';
import { useState } from 'react';
import axios from 'axios';
import {
  formatPrice,
  calculateSubtotal,
  calculateTax,
  calculateTotal
} from '../utils/helpers';

export default function CheckoutPage({ navigate, cartItems, isLoggedIn, user, logout, setCartItems }) {
  const [shippingInfo, setShippingInfo] = useState({
    street: '',
    state: '',
    zipCode: '',
    country: 'India'
  });

  const [paymentMethod, setPaymentMethod] = useState('Cash on Delivery');

  const handlePlaceOrder = async () => {
    if (!shippingInfo.street || !shippingInfo.state || !shippingInfo.zipCode) {
      alert('Please fill in all shipping details');
      return;
    }

    try {
      const token = localStorage.getItem('token');

      // âœ… Step 1: Place Order
      const orderData = {
        shippingAddress: `${shippingInfo.street}, ${shippingInfo.state}, ${shippingInfo.zipCode}, ${shippingInfo.country}`,
        paymentMethod: paymentMethod,
        totalAmount: calculateTotal(cartItems)
      };

      await axios.post('http://localhost:8080/api/orders', orderData, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      // âœ… Step 2: Clear Cart in Backend
      await axios.delete(`http://localhost:8080/api/cart/clear?email=${user.email}`, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      // âœ… Step 3: Clear Cart in Frontend
      setCartItems([]);

      alert(' Order placed successfully! Your cart has been cleared.');
      navigate('/home');
    } catch (error) {
      console.error('Error placing order:', error);
      alert('Failed to place order. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        navigate={navigate}
        cartItems={cartItems}
        isLoggedIn={isLoggedIn}
        user={user}
        logout={logout}
      />

      <main className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold mb-8">Checkout</h1>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Order Summary</h2>
            <div className="space-y-2">
              {cartItems.length === 0 ? (
                <div className="text-gray-600 py-4">Your cart is empty</div>
              ) : (
                <>
                  {cartItems.map((item) => (
                    <div key={item.id} className="flex justify-between items-center py-2">
                      <span className="text-gray-600">
                        {item.name} x {item.quantity}
                      </span>
                      <span className="font-medium">
                        {formatPrice((item.price || 0) * (item.quantity || 0))}
                      </span>
                    </div>
                  ))}
                  <div className="border-t border-gray-200 pt-2 mt-4">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-600">Subtotal:</span>
                      <span className="font-medium">
                        {formatPrice(calculateSubtotal(cartItems))}
                      </span>
                    </div>
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-gray-600">Tax (18%):</span>
                      <span className="font-medium">
                        {formatPrice(calculateTax(calculateSubtotal(cartItems)))}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-lg font-bold">Total:</span>
                      <span className="text-2xl font-bold text-blue-600">
                        {formatPrice(calculateTotal(cartItems))}
                      </span>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          <div className="border-t border-gray-200 pt-6 mb-8"></div>

          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-4">Shipping Address</h2>
            <div className="space-y-4">
              <input
                type="text"
                value={shippingInfo.street}
                onChange={(e) =>
                  setShippingInfo({ ...shippingInfo, street: e.target.value })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Enter your street address"
              />

              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  value={shippingInfo.state}
                  onChange={(e) =>
                    setShippingInfo({ ...shippingInfo, state: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="State"
                />

                <input
                  type="text"
                  value={shippingInfo.zipCode}
                  onChange={(e) =>
                    setShippingInfo({ ...shippingInfo, zipCode: e.target.value })
                  }
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Zip Code"
                />
              </div>

              <select
                value={shippingInfo.country}
                onChange={(e) =>
                  setShippingInfo({ ...shippingInfo, country: e.target.value })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option>India</option>
                <option>United States</option>
                <option>United Kingdom</option>
                <option>Canada</option>
                <option>Australia</option>
              </select>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Payment Method:
                </label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="Cash on Delivery">Cash on Delivery</option>
                  <option value="UPI">UPI</option>
                  <option value="Bank Transfer">Bank Transfer</option>
                </select>
              </div>
            </div>
          </div>

          <button
            onClick={handlePlaceOrder}
            disabled={cartItems.length === 0}
            className="w-full bg-blue-600 text-white py-4 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 font-semibold text-lg disabled:bg-gray-400 disabled:cursor-not-allowed"
          >
            Place Order
          </button>
        </div>
      </main>
    </div>
  );
}