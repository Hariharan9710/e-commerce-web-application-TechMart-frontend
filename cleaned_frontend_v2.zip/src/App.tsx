import { Routes, Route } from 'react-router-dom';

import HomePage from './Pages/HomePage';
import LoginPage from './Pages/LoginPage';
import RegisterPage from './Pages/RegisterPage';
import AllProductsPage from './Pages/AllProductsPage';
import CategoryProductsPage from './Pages/CategoryProductsPage';
import ProductDetailPage from './Pages/ProductDetailPage';
import ShoppingCartPage from './Pages/ShoppingCartPage';
import CheckoutPage from './Pages/CheckoutPage';
import ProfilePage from './Pages/ProfilePage';
import CustomerHelpPage from './Pages/CustomerHelpPage';
import AdminReturnManagement from './Admin/AdminReturnManagement';
import AdminLoginPage from './Admin/AdminLoginPage';
import AdminDashboard from './Admin/AdminDashboard';
import AdminProductManagement from './Admin/AdminProductManagement';
import AdminOrderManagement from './Admin/AdminOrderManagement';

import withAppProps from './WithAppProps';

const Home = withAppProps(HomePage);
const Login = withAppProps(LoginPage);
const Register = withAppProps(RegisterPage);
const AllProducts = withAppProps(AllProductsPage);
const CategoryProducts = withAppProps(CategoryProductsPage);
const ProductDetail = withAppProps(ProductDetailPage);
const ShoppingCart = withAppProps(ShoppingCartPage);
const Checkout = withAppProps(CheckoutPage);
const Profile = withAppProps(ProfilePage);
const CustomerHelp = withAppProps(CustomerHelpPage);

const AdminLogin = withAppProps(AdminLoginPage);
const AdminDash = withAppProps(AdminDashboard);
const AdminProducts = withAppProps(AdminProductManagement);
const AdminOrders = withAppProps(AdminOrderManagement);
const AdminReturns = withAppProps(AdminReturnManagement);

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/all-products" element={<AllProducts />} />
      <Route path="/category-products" element={<CategoryProducts />} />
      <Route path="/product-detail" element={<ProductDetail />} />
      <Route path="/cart" element={<ShoppingCart />} />
      <Route path="/checkout" element={<Checkout />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="/help" element={<CustomerHelp />} />

      <Route path="/admin-login" element={<AdminLogin />} />
      <Route path="/admin-dashboard" element={<AdminDash />} />
      <Route path="/admin-products" element={<AdminProducts />} />
      <Route path="/admin-orders" element={<AdminOrders />} />
      <Route path="/admin-returns" element={<AdminReturns />} />

      {/* Fallback */}
      <Route path="*" element={<Home />} />
    </Routes>
  );
}
