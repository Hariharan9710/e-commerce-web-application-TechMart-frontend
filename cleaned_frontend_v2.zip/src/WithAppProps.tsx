import { ComponentType } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "./hooks/useAuth";
import { useCart } from "./hooks/useCart";

export default function withAppProps<P>(Component: ComponentType<any>) {
  return function Wrapper(props: P) {
    const navigate = useNavigate();
    const { user, isLoggedIn, logout, login } = useAuth();
    const { cartItems, addToCart } = useCart();

    return (
      <Component
        {...props}
        navigate={navigate}
        user={user}
        isLoggedIn={isLoggedIn}
        logout={logout}
        login={login}
        cartItems={cartItems}
        addToCart={addToCart}
      />
    );
  };
}
