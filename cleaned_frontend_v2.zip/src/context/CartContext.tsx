import { createContext, useContext, useMemo, useState, ReactNode } from "react";

export type CartItem = {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image?: string;
  [key: string]: any;
};

type CartContextType = {
  cartItems: CartItem[];
  addToCart: (item: CartItem, qty?: number) => void;
  removeFromCart: (id: string) => void;
  clearCart: () => void;
  setQuantity: (id: string, qty: number) => void;
  subtotal: number;
  total: number;
  totalQty: number;
};

const CartContext = createContext<CartContextType | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const addToCart: CartContextType["addToCart"] = (item, qty = 1) => {
    setCartItems(prev => {
      const idx = prev.findIndex(p => p.id === item.id);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = { ...copy[idx], quantity: (copy[idx].quantity || 0) + qty };
        return copy;
      }
      return [...prev, { ...item, quantity: qty }];
    });
  };

  const removeFromCart = (id: string) => setCartItems(prev => prev.filter(p => p.id !== id));
  const clearCart = () => setCartItems([]);
  const setQuantity = (id: string, qty: number) => setCartItems(prev => prev.map(p => p.id === id ? { ...p, quantity: qty } : p));

  const subtotal = useMemo(() => cartItems.reduce((s, i) => s + (i.price || 0) * (i.quantity || 0), 0), [cartItems]);
  const total = useMemo(() => subtotal * 1.18, [subtotal]);
  const totalQty = useMemo(() => cartItems.reduce((s, i) => s + (i.quantity || 0), 0), [cartItems]);

  const value = useMemo(() => ({
    cartItems, addToCart, removeFromCart, clearCart, setQuantity, subtotal, total, totalQty
  }), [cartItems, subtotal, total, totalQty]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCartContext() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCartContext must be used within CartProvider");
  return ctx;
}
