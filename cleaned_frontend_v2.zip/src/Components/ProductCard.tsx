// import { ShoppingCart } from 'lucide-react';
// import { formatPrice } from '../utils/helpers';

// export default function ProductCard({ product, navigate, addToCart }) {
//   return (
//     <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition cursor-pointer">
//       <div
//         onClick={() => navigate('product-detail', product)}
//         className="h-56 overflow-hidden bg-gray-100 flex items-center justify-center p-4"
//       >
//         {/* âœ… Changed: object-cover â†’ object-contain + added p-4 padding */}
//        <img
//   // Fixed: added optional chaining and fallback for replace
//   src={
//     product.image?.startsWith('http')
//       ? product.image
//       : `http://localhost:8080/images/${product.image?.replace(/^\/+/, '') || ''}`
//   }
//   alt={product.name}
//   className="w-full h-full object-contain hover:scale-105 transition duration-300"
// />
//       </div>

//       <div className="p-4">
//         <h3 className="text-lg font-bold mb-1 line-clamp-1">{product.name}</h3>
//         <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>

//         <div className="flex justify-between items-center text-sm mb-3">
//           <span className="text-gray-600">{product.category}</span>
//           <span className="font-medium text-gray-700">{product.brand}</span>
//         </div>

//         <div className="flex items-center mb-4">
//           <div className="flex text-yellow-400">
//             {[...Array(4)].map((_, i) => (
//               <span key={i}>★</span>
//             ))}
//             <span className="text-gray-300">★</span>
//           </div>
//           <span className="ml-2 text-sm text-gray-600">({product.rating})</span>
//         </div>

//         <div className="flex justify-between items-center">
//           <div>
//             <div className="text-2xl font-bold text-blue-600">
//               {formatPrice(product.price)}
//             </div>
//             <div className="text-xs text-green-600 font-semibold bg-green-100 px-2 py-1 rounded inline-block mt-1">
//               Stock: {product.stock}
//             </div>
//           </div>
//           <button
//             onClick={(e) => {
//               e.stopPropagation();
//               addToCart && addToCart(product, 1);
//             }}
//             className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 font-semibold hover:bg-blue-700 transition"
//           >
//             <ShoppingCart className="w-4 h-4" />
//             <span>Add</span>
//           </button>
//         </div>
//       </div>
//     </div>
//   );
// }


import { ShoppingCart } from 'lucide-react';
import { formatPrice } from '../utils/helpers';

export default function ProductCard({ product, navigate, addToCart }) {
  return (
    <div className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition cursor-pointer">
      <div
        onClick={() => navigate('product-detail', product)}
        className="h-56 overflow-hidden bg-gray-100 flex items-center justify-center p-4"
      >
        <img
          src={
            product.image?.startsWith('http')
              ? product.image
              : `http://localhost:8080/images/${product.image?.replace(/^\/+/, '') || ''}`
          }
          alt={product.name}
          className="w-full h-full object-contain hover:scale-105 transition duration-300"
        />
      </div>

      <div className="p-4">
        <h3 className="text-lg font-bold mb-1 line-clamp-1">{product.name}</h3>
        <p className="text-sm text-gray-600 mb-3 line-clamp-2">{product.description}</p>

        <div className="flex justify-between items-center text-sm mb-3">
          <span className="text-gray-600">{product.category}</span>
          <span className="font-medium text-gray-700">{product.brand}</span>
        </div>

        <div className="flex items-center mb-4">
          <div className="flex text-yellow-400">
            {[...Array(4)].map((_, i) => (
              <span key={i}>★</span>
            ))}
            <span className="text-gray-300">★</span>
          </div>
          <span className="ml-2 text-sm text-gray-600">({product.rating})</span>
        </div>

        <div className="flex justify-between items-center">
          <div>
            <div className="text-2xl font-bold text-blue-600">
              {formatPrice(product.price)}
            </div>

            {/* ✅ Updated Stock Badge Color Logic */}
            <div
              className={`text-xs font-semibold px-2 py-1 rounded inline-block mt-1 ${
                product.stock < 10
                  ? 'text-red-600 bg-red-100'
                  : 'text-green-600 bg-green-100'
              }`}
            >
              Stock: {product.stock}
            </div>
          </div>

          <button
            onClick={(e) => {
              e.stopPropagation();
              addToCart && addToCart(product, 1);
            }}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 font-semibold hover:bg-blue-700 transition"
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Add</span>
          </button>
        </div>
      </div>
    </div>
  );
}
