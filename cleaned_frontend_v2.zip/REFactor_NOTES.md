# What I changed
- Replaced manual routing and prop-drilling with Context API (Auth + Cart).
- Wrapped app with `BrowserRouter`, `AuthProvider`, `CartProvider` in `src/main.tsx`.
- Added `withAppProps` HOC so existing pages receive the props they expect from context automatically.
- Kept your backend API integration untouched (axios interceptors still use localStorage token).

## How to migrate pages (optional, better)
Replace props usage with hooks inside each page:
```tsx
import { useAuth } from '../hooks/useAuth';
import { useCart } from '../hooks/useCart';
import { useNavigate } from 'react-router-dom';

const Page = () => {
  const { user, isLoggedIn, login, logout } = useAuth();
  const { cartItems, addToCart } = useCart();
  const navigate = useNavigate();
  // ...
};
```
Then remove the HOC for that page in `App.tsx` (use component directly).
