// import { useState, useEffect } from 'react';
// import { Package, CheckCircle, XCircle, ArrowLeft, AlertCircle } from 'lucide-react';
// import { adminAPI } from '../services/api';
// import { formatPrice } from '../utils/helpers';

// export default function AdminReturnManagement({ navigate }) {
//   const [returns, setReturns] = useState([]);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     loadReturns();
//   }, []);

//   const loadReturns = async () => {
//     try {
//       const response = await adminAPI.getAllReturnRequests();
//       setReturns(response.data);
//     } catch (error) {
//       console.error('Error loading returns:', error);
//       alert('Failed to load returns');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleApprove = async (orderId) => {
//     if (!window.confirm('Approve this return request? Customer will be notified to ship the product back.')) return;
//     try {
//       await adminAPI.approveReturn(orderId);
//       alert('✅ Return approved! Customer notified to ship product.');
//       loadReturns();
//     } catch (error) {
//       alert('Failed to approve return');
//     }
//   };

//   const handleReject = async (orderId) => {
//     const reason = window.prompt('Enter rejection reason:');
//     if (!reason || reason.trim() === '') {
//       alert('Rejection reason is required');
//       return;
//     }
    
//     try {
//       await adminAPI.rejectReturn(orderId, reason);
//       alert('❌ Return rejected. Customer has been notified.');
//       loadReturns();
//     } catch (error) {
//       alert('Failed to reject return');
//     }
//   };

//   const handleReturnReceived = async (orderId) => {
//     const condition = window.confirm(
//       '🔍 Product Condition Check\n\n' +
//       'Is the returned product in GOOD condition?\n\n' +
//       '✅ Click OK if product is:\n' +
//       '   • Undamaged\n' +
//       '   • Complete with all accessories\n' +
//       '   • In resalable condition\n\n' +
//       '❌ Click Cancel if product is:\n' +
//       '   • Damaged or broken\n' +
//       '   • Missing parts\n' +
//       '   • Not in original condition'
//     );

//     try {
//       await adminAPI.confirmReturnReceived(orderId, condition ? 'GOOD' : 'DAMAGED');
      
//       if (condition) {
//         alert('✅ Return accepted! Product is in good condition. You can now process the refund.');
//       } else {
//         alert('❌ Return rejected due to poor condition. Customer will be notified.');
//       }
      
//       loadReturns();
//     } catch (error) {
//       alert('Failed to update status');
//     }
//   };

//   const handleInitiateRefund = async (orderId) => {
//     if (!window.confirm('💰 Initiate refund process?\n\nThis will:\n• Restore product stock\n• Mark refund as initiated\n• Begin payment processing')) return;
    
//     try {
//       await adminAPI.initiateRefund(orderId);
//       alert('✅ Refund initiated! Stock has been restored. Complete the refund payment next.');
//       loadReturns();
//     } catch (error) {
//       alert('Failed to initiate refund');
//     }
//   };

//   const handleCompleteRefund = async (orderId) => {
//     if (!window.confirm('✅ Mark refund as completed?\n\nConfirm that payment has been processed to the customer.')) return;
    
//     try {
//       await adminAPI.completeRefund(orderId);
//       alert('✅ Refund completed successfully! Return process is now finished.');
//       loadReturns();
//     } catch (error) {
//       alert('Failed to complete refund');
//     }
//   };

//   const isEligibleFor15Days = (deliveredAt) => {
//     if (!deliveredAt) return false;
//     const delivered = new Date(deliveredAt);
//     const fifteenDaysAgo = new Date();
//     fifteenDaysAgo.setDate(fifteenDaysAgo.getDate() - 15);
//     return delivered >= fifteenDaysAgo;
//   };

//   const getStatusBadge = (status) => {
//     const statusConfig = {
//       'REQUESTED': { color: 'bg-yellow-100 text-yellow-800', text: '⏳ Awaiting Approval' },
//       'APPROVED': { color: 'bg-blue-100 text-blue-800', text: '📦 Awaiting Product' },
//       'REJECTED': { color: 'bg-red-100 text-red-800', text: '❌ Rejected' },
//       'RETURN_RECEIVED': { color: 'bg-purple-100 text-purple-800', text: '✅ Product Received' },
//       'REFUND_INITIATED': { color: 'bg-orange-100 text-orange-800', text: '💰 Refund Processing' },
//       'REFUND_COMPLETED': { color: 'bg-green-100 text-green-800', text: '✅ Refund Complete' },
//       'RETURN_REJECTED': { color: 'bg-red-100 text-red-800', text: '❌ Return Rejected' }
//     };

//     const config = statusConfig[status] || { color: 'bg-gray-100 text-gray-800', text: status };
//     return (
//       <span className={`px-3 py-1 rounded-full text-sm font-medium ${config.color}`}>
//         {config.text}
//       </span>
//     );
//   };

//   if (loading) {
//     return (
//       <div className="min-h-screen bg-gray-50 flex items-center justify-center">
//         <div className="text-center">
//           <Package className="w-12 h-12 text-blue-600 mx-auto mb-4 animate-pulse" />
//           <p className="text-gray-600">Loading return requests...</p>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="min-h-screen bg-gray-50">
//       <div className="max-w-7xl mx-auto px-4 py-8">
//         {/* Header */}
//         <div className="mb-8">
//           <button
//             onClick={() => navigate('/admin-dashboard')}
//             className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-4 font-medium"
//           >
//             <ArrowLeft className="w-5 h-5" />
//             Back to Dashboard
//           </button>
//           <h1 className="text-3xl font-bold mb-2">Return Requests Management</h1>
//           <p className="text-gray-600">Review and process customer return requests</p>
//         </div>

//         {/* Info Banner */}
//         <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
//           <div className="flex gap-3">
//             <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
//             <div className="text-sm text-blue-800">
//               <strong>Return Process:</strong> Approve request → Wait for product → Check condition → Initiate refund → Complete refund
//             </div>
//           </div>
//         </div>

//         {/* Returns List */}
//         {returns.length === 0 ? (
//           <div className="bg-white rounded-lg shadow-md p-12 text-center">
//             <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
//             <h3 className="text-xl font-semibold text-gray-700 mb-2">No Return Requests</h3>
//             <p className="text-gray-500">All return requests have been processed</p>
//           </div>
//         ) : (
//           <div className="space-y-4">
//             {returns.map((order) => (
//               <div key={order.id} className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition">
//                 {/* Order Header */}
//                 <div className="flex flex-wrap justify-between items-start mb-4 gap-4">
//                   <div>
//                     <h3 className="font-bold text-lg mb-1">Order #{order.id}</h3>
//                     <p className="text-sm text-gray-600">
//                       Customer: {order.user.firstName} {order.user.lastName}
//                     </p>
//                     <p className="text-sm text-gray-600">{order.user.email}</p>
//                     <p className="text-lg font-semibold text-blue-600 mt-2">
//                       {formatPrice(order.totalAmount)}
//                     </p>
//                   </div>
//                   <div className="text-right">
//                     {getStatusBadge(order.returnStatus)}
//                     <div className="mt-2">
//                       {isEligibleFor15Days(order.deliveredAt) ? (
//                         <span className="text-xs px-2 py-1 rounded-full bg-green-100 text-green-800">
//                           ✓ Eligible for Return
//                         </span>
//                       ) : (
//                         <span className="text-xs px-2 py-1 rounded-full bg-red-100 text-red-800">
//                           ✗ Return Period Expired
//                         </span>
//                       )}
//                     </div>
//                   </div>
//                 </div>

//                 {/* Order Details */}
//                 <div className="border-t border-gray-200 pt-4 mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
//                   <div>
//                     <p className="text-sm mb-2">
//                       <strong className="text-gray-700">Return Reason:</strong>
//                       <span className="ml-2 text-gray-600">{order.returnReason}</span>
//                     </p>
//                     <p className="text-sm mb-2">
//                       <strong className="text-gray-700">Payment Method:</strong>
//                       <span className="ml-2 text-gray-600">{order.paymentMethod}</span>
//                     </p>
//                   </div>
//                   <div>
//                     <p className="text-sm mb-2">
//                       <strong className="text-gray-700">Delivered:</strong>
//                       <span className="ml-2 text-gray-600">
//                         {new Date(order.deliveredAt).toLocaleDateString('en-IN')}
//                       </span>
//                     </p>
//                     <p className="text-sm mb-2">
//                       <strong className="text-gray-700">Return Requested:</strong>
//                       <span className="ml-2 text-gray-600">
//                         {new Date(order.returnRequestedAt).toLocaleDateString('en-IN')}
//                       </span>
//                     </p>
//                   </div>
//                 </div>

//                 {/* Action Buttons based on Status */}
//                 <div className="border-t border-gray-200 pt-4">
//                   {/* Step 1: Approve/Reject Request */}
//                   {order.returnStatus === 'REQUESTED' && isEligibleFor15Days(order.deliveredAt) && (
//                     <div className="flex gap-3">
//                       <button
//                         onClick={() => handleApprove(order.id)}
//                         className="flex-1 flex items-center justify-center gap-2 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition font-semibold"
//                       >
//                         <CheckCircle className="w-5 h-5" />
//                         Approve Return Request
//                       </button>
//                       <button
//                         onClick={() => handleReject(order.id)}
//                         className="flex-1 flex items-center justify-center gap-2 bg-red-600 text-white py-3 rounded-lg hover:bg-red-700 transition font-semibold"
//                       >
//                         <XCircle className="w-5 h-5" />
//                         Reject Request
//                       </button>
//                     </div>
//                   )}

//                   {/* Step 2: Confirm Product Received */}
//                   {order.returnStatus === 'APPROVED' && (
//                     <div>
//                       <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-3">
//                         <p className="text-sm text-blue-800">
//                           <strong>Waiting for product:</strong> Customer has been notified to ship the product back
//                         </p>
//                       </div>
//                       <button
//                         onClick={() => handleReturnReceived(order.id)}
//                         className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition font-semibold"
//                       >
//                         <Package className="w-5 h-5" />
//                         Product Received - Check Condition
//                       </button>
//                     </div>
//                   )}

//                   {/* Step 3: Initiate Refund */}
//                   {order.returnStatus === 'RETURN_RECEIVED' && (
//                     <div>
//                       <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-3">
//                         <p className="text-sm text-green-800">
//                           <strong>✅ Product accepted:</strong> Product is in good condition. Ready to process refund.
//                         </p>
//                       </div>
//                       <button
//                         onClick={() => handleInitiateRefund(order.id)}
//                         className="w-full flex items-center justify-center gap-2 bg-orange-600 text-white py-3 rounded-lg hover:bg-orange-700 transition font-semibold"
//                       >
//                         💰 Initiate Refund & Restore Stock
//                       </button>
//                     </div>
//                   )}

//                   {/* Step 4: Complete Refund */}
//                   {order.returnStatus === 'REFUND_INITIATED' && (
//                     <div>
//                       <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 mb-3">
//                         <p className="text-sm text-orange-800">
//                           <strong>💰 Refund processing:</strong> Stock restored. Complete the payment refund to customer.
//                         </p>
//                       </div>
//                       <button
//                         onClick={() => handleCompleteRefund(order.id)}
//                         className="w-full flex items-center justify-center gap-2 bg-green-600 text-white py-3 rounded-lg hover:bg-green-700 transition font-semibold"
//                       >
//                         <CheckCircle className="w-5 h-5" />
//                         Mark Refund as Completed
//                       </button>
//                     </div>
//                   )}

//                   {/* Final Status Messages */}
//                   {order.returnStatus === 'REFUND_COMPLETED' && (
//                     <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
//                       <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
//                       <p className="text-green-800 font-semibold">
//                         ✅ Return process completed successfully
//                       </p>
//                       <p className="text-sm text-green-700 mt-1">
//                         Refund processed on {order.refundCompletedAt && new Date(order.refundCompletedAt).toLocaleDateString('en-IN')}
//                       </p>
//                     </div>
//                   )}

//                   {order.returnStatus === 'REJECTED' && (
//                     <div className="bg-red-50 border border-red-200 rounded-lg p-4">
//                       <p className="text-red-800 font-semibold">❌ Return Request Rejected</p>
//                       {order.returnRejectionReason && (
//                         <p className="text-sm text-red-700 mt-1">
//                           Reason: {order.returnRejectionReason}
//                         </p>
//                       )}
//                     </div>
//                   )}

//                   {order.returnStatus === 'RETURN_REJECTED' && (
//                     <div className="bg-red-50 border border-red-200 rounded-lg p-4">
//                       <p className="text-red-800 font-semibold">❌ Return Rejected - Poor Condition</p>
//                       <p className="text-sm text-red-700 mt-1">
//                         Product was not in acceptable condition for return
//                       </p>
//                     </div>
//                   )}

//                   {/* Expired Return Window */}
//                   {order.returnStatus === 'REQUESTED' && !isEligibleFor15Days(order.deliveredAt) && (
//                     <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
//                       <p className="text-gray-700 font-semibold">⚠️ Return Period Expired</p>
//                       <p className="text-sm text-gray-600 mt-1">
//                         This order is beyond the 15-day return window
//                       </p>
//                     </div>
//                   )}
//                 </div>
//               </div>
//             ))}
//           </div>
//         )}
//       </div>
//     </div>
//   );
// }

import { useState, useEffect } from 'react';
import { Package, CheckCircle, XCircle, ArrowLeft, AlertCircle } from 'lucide-react';
import { adminAPI } from '../services/api';
import { formatPrice } from '../utils/helpers';

export default function AdminReturnManagement({ navigate }) {
  const [returns, setReturns] = useState([]);
  const [loading, setLoading] = useState(true);

  // ✅ Modal States
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState(''); // 'reject' | 'condition'
  const [selectedOrderId, setSelectedOrderId] = useState(null);
  const [modalInput, setModalInput] = useState('');

  useEffect(() => {
    loadReturns();
  }, []);

  const loadReturns = async () => {
    try {
      const response = await adminAPI.getAllReturnRequests();
      setReturns(response.data);
    } catch (error) {
      console.error('Error loading returns:', error);
      alert('Failed to load returns');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (orderId) => {
    if (!window.confirm('Approve this return request? Customer will be notified to ship the product back.')) return;
    try {
      await adminAPI.approveReturn(orderId);
      alert('✅ Return approved! Customer notified to ship product.');
      loadReturns();
    } catch (error) {
      alert('Failed to approve return');
    }
  };

  // ✅ NEW REPLACED REJECT BUTTON → Opens Modal
  const handleReject = (orderId) => {
    setSelectedOrderId(orderId);
    setModalType('reject');
    setModalInput('');
    setShowModal(true);
  };

  const confirmReject = async () => {
    if (!modalInput.trim()) {
      alert('Please enter a reason');
      return;
    }
    try {
      await adminAPI.rejectReturn(selectedOrderId, modalInput);
      alert('❌ Return rejected');
      setShowModal(false);
      loadReturns();
    } catch (error) {
      alert('Failed to reject return');
    }
  };

  // ✅ NEW REPLACED PRODUCT RECEIVED BUTTON → Opens Modal
  const handleReturnReceived = (orderId) => {
    setSelectedOrderId(orderId);
    setModalType('condition');
    setShowModal(true);
  };

  const confirmCondition = async (condition) => {
    try {
      await adminAPI.confirmReturnReceived(selectedOrderId, condition);
      alert(condition === 'GOOD' ? '✅ Return accepted' : '❌ Return rejected due to condition');
      setShowModal(false);
      loadReturns();
    } catch (error) {
      alert('Failed to update status');
    }
  };

  const handleInitiateRefund = async (orderId) => {
    if (!window.confirm('Initiate refund process?')) return;
    try {
      await adminAPI.initiateRefund(orderId);
      alert('✅ Refund initiated! Stock has been restored.');
      loadReturns();
    } catch (error) {
      alert('Failed to initiate refund');
    }
  };

  const handleCompleteRefund = async (orderId) => {
    if (!window.confirm('Confirm refund is completed?')) return;
    try {
      await adminAPI.completeRefund(orderId);
      alert('✅ Refund completed successfully!');
      loadReturns();
    } catch (error) {
      alert('Failed to complete refund');
    }
  };

  const isEligibleFor15Days = (deliveredAt) => {
    if (!deliveredAt) return false;
    const delivered = new Date(deliveredAt);
    const fifteenDaysAgo = new Date();
    fifteenDaysAgo.setDate(fifteenDaysAgo.getDate() - 15);
    return delivered >= fifteenDaysAgo;
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      'REQUESTED': { color: 'bg-yellow-100 text-yellow-800', text: '⏳ Awaiting Approval' },
      'APPROVED': { color: 'bg-blue-100 text-blue-800', text: '📦 Awaiting Product' },
      'REJECTED': { color: 'bg-red-100 text-red-800', text: '❌ Rejected' },
      'RETURN_RECEIVED': { color: 'bg-purple-100 text-purple-800', text: '✅ Product Received' },
      'REFUND_INITIATED': { color: 'bg-orange-100 text-orange-800', text: '💰 Refund Processing' },
      'REFUND_COMPLETED': { color: 'bg-green-100 text-green-800', text: '✅ Refund Complete' },
      'RETURN_REJECTED': { color: 'bg-red-100 text-red-800', text: '❌ Return Rejected' }
    };
    const config = statusConfig[status] || { color: 'bg-gray-100 text-gray-800', text: status };
    return <span className={`px-3 py-1 rounded-full text-sm font-medium ${config.color}`}>{config.text}</span>;
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">

      {/* ✅ MODAL POPUP */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full shadow-lg">
            <h3 className="text-xl font-bold mb-4">
              {modalType === 'reject' ? 'Rejection Reason' : 'Product Condition Check'}
            </h3>

            {modalType === 'reject' ? (
              <>
                <textarea
                  value={modalInput}
                  onChange={(e) => setModalInput(e.target.value)}
                  placeholder="Enter rejection reason..."
                  className="w-full border rounded p-3 mb-4"
                  rows="4"
                />
                <div className="flex gap-3">
                  <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                  <button onClick={confirmReject} className="px-4 py-2 bg-red-600 text-white rounded">Submit</button>
                </div>
              </>
            ) : (
              <>
                <p className="mb-4">Is the product in good condition?</p>
                <div className="space-y-2 mb-4">
                  <p>✅ Good: Undamaged, complete, resalable</p>
                  <p>❌ Damaged: Broken, dirty, modified</p>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => confirmCondition('DAMAGED')} className="px-4 py-2 bg-red-600 text-white rounded">Damaged</button>
                  <button onClick={() => confirmCondition('GOOD')} className="px-4 py-2 bg-green-600 text-white rounded">Good Condition</button>
                  <button onClick={() => setShowModal(false)} className="px-4 py-2 bg-gray-200 rounded">Cancel</button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* ORIGINAL UI BELOW — UNTOUCHED */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        <button onClick={() => navigate('/admin-dashboard')} className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-4 font-medium">
          <ArrowLeft className="w-5 h-5" /> Back to Dashboard
        </button>

        <h1 className="text-3xl font-bold mb-2">Return Requests Management</h1>

        {returns.length === 0 ? (
          <div>No return requests</div>
        ) : (
          returns.map((order) => (
            <div key={order.id} className="bg-white rounded-lg shadow-md p-6 mb-4">
              {/* SAME UI — NO CHANGE */}
              <div className="flex justify-between mb-4">
                <div>
                  <h3 className="font-bold">Order #{order.id}</h3>
                  <p>{order.user.email}</p>
                </div>
                {getStatusBadge(order.returnStatus)}
              </div>

              {order.returnStatus === 'REQUESTED' && (
                <div className="flex gap-3">
                  <button onClick={() => handleApprove(order.id)} className="bg-green-600 text-white px-4 py-2 rounded">Approve</button>
                  <button onClick={() => handleReject(order.id)} className="bg-red-600 text-white px-4 py-2 rounded">Reject</button>
                </div>
              )}

              {order.returnStatus === 'APPROVED' && (
                <button onClick={() => handleReturnReceived(order.id)} className="bg-blue-600 text-white w-full py-2 rounded">
                  Product Received - Check Condition
                </button>
              )}

              {order.returnStatus === 'RETURN_RECEIVED' && (
                <button onClick={() => handleInitiateRefund(order.id)} className="bg-orange-600 text-white w-full py-2 rounded">
                  Initiate Refund
                </button>
              )}

              {order.returnStatus === 'REFUND_INITIATED' && (
                <button onClick={() => handleCompleteRefund(order.id)} className="bg-green-600 text-white w-full py-2 rounded">
                  Complete Refund
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
