import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { ArrowLeft, Edit, Trash2, Plus, Save, X } from 'lucide-react';
import { adminAPI, productAPI } from '../services/api';
import { formatPrice } from '../utils/helpers';

export default function AdminProductManagement({ navigate }) {
  const location = useLocation();
const category = location.state?.category || null;
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingProduct, setEditingProduct] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [imageFile, setImageFile] = useState(null);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: category || '',
    brand: '',
    price: '',
    stock: '',
    rating: 4.0
  });

  useEffect(() => {
    loadProducts();
  }, [category]);

  const loadProducts = async () => {
    try {
      const response = category
        ? await productAPI.getProductsByCategory(category)
        : await productAPI.getAllProducts();
      setProducts(response.data);
    } catch (error) {
      console.error('Error loading products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'price' || name === 'stock' || name === 'rating' ? parseFloat(value) || 0 : value
    }));
  };

  // ✅ Add Product with FormData
  const handleAddProduct = async (e) => {
  e.preventDefault();
  try {
    const form = new FormData();
    form.append('name', formData.name);
    form.append('description', formData.description);
    form.append('category', formData.category);
    form.append('brand', formData.brand);
    form.append('price', formData.price);
    form.append('stock', formData.stock);
    form.append('rating', formData.rating);
    if (imageFile) {
      form.append('image', imageFile);
      console.log('Uploading image:', imageFile.name);  // ✅ Add logging
    }

    const response = await adminAPI.addProduct(form);
    console.log('Product added:', response.data);  // ✅ Check response
    alert('Product added successfully!');
    setShowAddForm(false);
    resetForm();
    loadProducts();
  } catch (error) {
    console.error('Error adding product:', error);
    alert('Failed to add product: ' + (error.response?.data?.message || error.message));
  }
};

// Same for handleUpdateProduct

  // ✅ Update Product with FormData
  const handleUpdateProduct = async (e) => {
    e.preventDefault();
    try {
      const form = new FormData();
      form.append('name', formData.name);
      form.append('description', formData.description);
      form.append('category', formData.category);
      form.append('brand', formData.brand);
      form.append('price', formData.price);
      form.append('stock', formData.stock);
      form.append('rating', formData.rating);
      if (imageFile) form.append('image', imageFile);

      await adminAPI.updateProduct(editingProduct.id, form);
      alert('Product updated successfully!');
      setEditingProduct(null);
      resetForm();
      loadProducts();
    } catch (error) {
      console.error('Error updating product:', error);
      alert('Failed to update product');
    }
  };

  const handleDeleteProduct = async (id) => {
  if (!window.confirm('Are you sure you want to delete this product?')) return;  // ✅ Use window.confirm

  try {
    await adminAPI.deleteProduct(id);
    alert('Product deleted successfully!');
    loadProducts();  // ✅ Reload products after delete
  } catch (error) {
    console.error('Error deleting product:', error);
    alert('Failed to delete product: ' + (error.response?.data?.message || error.message));
  }
};

  const handleUpdateStock = async (productId, newStock) => {
    try {
      await adminAPI.updateStock(productId, newStock);
      alert('Stock updated successfully!');
      loadProducts();
    } catch (error) {
      console.error('Error updating stock:', error);
      alert('Failed to update stock');
    }
  };

  const startEditing = (product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description || '',
      category: product.category,
      brand: product.brand,
      price: product.price,
      stock: product.stock,
      rating: product.rating
    });
    setImageFile(null);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      category: category || '',
      brand: '',
      price: '',
      stock: '',
      rating: 4.0
    });
    setImageFile(null);
  };

  const cancelEdit = () => {
    setEditingProduct(null);
    setShowAddForm(false);
    resetForm();
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p className="text-gray-600">Loading products...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <button
              onClick={() => navigate('admin-dashboard')}
              className="flex items-center gap-2 text-blue-600 font-medium mb-4 hover:underline"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Dashboard
            </button>
            <h1 className="text-3xl font-bold">
              {category ? `${category} Products` : 'All Products'}
            </h1>
            <p className="text-gray-600">Manage your product inventory</p>
          </div>

          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition font-semibold"
          >
            <Plus className="w-5 h-5" />
            Add Product
          </button>
        </div>

        {/* Add/Edit Form Modal */}
        {(showAddForm || editingProduct) && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-8">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold">
                  {editingProduct ? 'Edit Product' : 'Add New Product'}
                </h2>
                <button onClick={cancelEdit} className="text-gray-400 hover:text-gray-600">
                  <X className="w-6 h-6" />
                </button>
              </div>

              <form onSubmit={editingProduct ? handleUpdateProduct : handleAddProduct} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Product Name</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-600"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows="3"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-600"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                    <input
                      type="text"
                      name="category"
                      value={formData.category}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Brand</label>
                    <input
                      type="text"
                      name="brand"
                      value={formData.brand}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-600"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Price (₹)</label>
                    <input
                      type="number"
                      name="price"
                      value={formData.price}
                      onChange={handleInputChange}
                      step="0.01"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Stock</label>
                    <input
                      type="number"
                      name="stock"
                      value={formData.stock}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-600"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Rating</label>
                    <input
                      type="number"
                      name="rating"
                      value={formData.rating}
                      onChange={handleInputChange}
                      step="0.1"
                      min="0"
                      max="5"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-600"
                      required
                    />
                  </div>
                </div>

                {/* ✅ File Upload Input */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Product Image</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => setImageFile(e.target.files[0])}
                    className="w-full"
                    required={!editingProduct}
                  />
                  {editingProduct && editingProduct.image && (
                    <img
                      src={editingProduct.image}
                      alt="Current"
                      className="w-24 h-24 object-cover rounded mt-2 border"
                    />
                  )}
                </div>

                <div className="flex gap-4 pt-4">
                  <button
                    type="submit"
                    className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition font-semibold"
                  >
                    <Save className="w-5 h-5" />
                    {editingProduct ? 'Update Product' : 'Add Product'}
                  </button>
                  <button
                    type="button"
                    onClick={cancelEdit}
                    className="flex-1 bg-gray-200 text-gray-700 px-6 py-3 rounded-lg hover:bg-gray-300 transition font-semibold"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Products Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Product</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Category</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Brand</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Price</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stock</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {products.map((product) => (
                  <tr key={product.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                      <img src={product.image?.startsWith("http") ? product.image : `http://localhost:8080/images/${product.image?.replace(/^\/+/, '')}`}
  alt={product.name}
  className="w-12 h-12 object-cover rounded"
/>

                        <div>
                          <p className="font-medium">{product.name}</p>
                          <p className="text-sm text-gray-500">
                            {product.description ? product.description.substring(0, 50) + '...' : 'No description'}
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm">{product.category}</td>
                    <td className="px-6 py-4 text-sm">{product.brand}</td>
                    <td className="px-6 py-4 text-sm font-medium">{formatPrice(product.price)}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          defaultValue={product.stock}
                           className={`w-20 px-2 py-1 border rounded text-center ${
    product.stock < 10 ? 'border-red-400 bg-red-50' : 'border-gray-300'
  }`}
                          onBlur={(e) => {
                            const newStock = parseInt(e.target.value);
                            if (newStock !== product.stock && newStock >= 0) {
                              handleUpdateStock(product.id, newStock);
                            }
                          }}
                        />
                        <span className={`px-2 py-1 text-xs font-medium rounded ${
  product.stock < 10 ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
}`}>
  {product.stock < 10 ? 'Low Stock' : 'In Stock'}
</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex gap-2">
                        <button
                          onClick={() => startEditing(product)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded transition"
                        >
                          <Edit className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(product.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded transition"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {products.length === 0 && (
            <div className="text-center py-12">
              <p className="text-gray-600">No products found</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
