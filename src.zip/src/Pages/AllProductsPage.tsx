import { useState, useEffect } from 'react';
import { Search } from 'lucide-react';
import Header from '../Components/Header';
import ProductCard from '../Components/ProductCard';
import { productAPI } from '../services/api';

export default function AllProductsPage({ navigate, addToCart, cartItems, isLoggedIn, user, logout }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProducts();
  }, []);

  const loadProducts = async () => {
  try {
    const response = await productAPI.getAllProducts();
    console.log('Products loaded:', response.data);  // âœ… Check if data is returned
    setProducts(response.data);
  } catch (error) {
    console.error('Error loading products:', error);
  } finally {
    setLoading(false);
  }
};

  const filteredProducts = products.filter(product =>
    product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
    product.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Header navigate={navigate} cartItems={cartItems} showSearch={true} searchQuery={searchQuery} setSearchQuery={setSearchQuery} isLoggedIn={isLoggedIn} user={user} logout={logout} />

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">All Products</h1>
          <p className="text-lg text-gray-600">Discover our complete collection of premium electronics</p>
        </div>

        <div className="mb-6 text-sm text-gray-600">
          Showing {filteredProducts.length} products
        </div>

        {loading ? (
          <div className="text-center py-20">
            <p className="text-gray-600">Loading products...</p>
          </div>
        ) : filteredProducts.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20">
            <Search className="w-16 h-16 text-gray-400 mb-4" />
            <h2 className="text-2xl font-bold mb-2">No products found</h2>
            <p className="text-gray-600 mb-6">Try adjusting your search</p>
            <button
              onClick={() => setSearchQuery('')}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg font-semibold hover:bg-blue-700 transition"
            >
              Clear Filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {filteredProducts.map((product) => (
            <ProductCard
  key={product.id}
  product={product}
  navigate={navigate}
  addToCart={addToCart}
/>

            ))}
          </div>
        )}
      </main>
    </div>
  );
}