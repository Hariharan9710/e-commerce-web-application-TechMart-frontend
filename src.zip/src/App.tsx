
import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';

import HomePage from './Pages/HomePage';
import LoginPage from './Pages/LoginPage';
import RegisterPage from './Pages/RegisterPage';
import AllProductsPage from './Pages/AllProductsPage';
import CategoryProductsPage from './Pages/CategoryProductsPage';
import ProductDetailPage from './Pages/ProductDetailPage';
import ShoppingCartPage from './Pages/ShoppingCartPage';
import CheckoutPage from './Pages/CheckoutPage';
import ProfilePage from './Pages/ProfilePage';
import CustomerHelpPage from './Pages/CustomerHelpPage';
import AdminReturnManagement from './Admin/AdminReturnManagement';


// ✅ NEW IMPORT
import OrderHistoryPage from './Pages/OrderHistoryPage';

// ✅ NEW IMPORT (Admin Order Management)
import AdminOrderManagement from './Admin/AdminOrderManagement';

import AdminLoginPage from './Admin/AdminLoginPage';
import AdminDashboard from './Admin/AdminDashboard';
import AdminProductManagement from './Admin/AdminProductManagement';

import { cartAPI, userAPI } from './services/api';

function AppContent() {
  const [cartItems, setCartItems] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState(null);
  const [categoryData, setCategoryData] = useState(null);

  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    const storedUser = localStorage.getItem('user');

    if (token && storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setIsLoggedIn(true);
      setUser(parsedUser);
      if (parsedUser.role === 'ADMIN') {
        navigate('/admin-dashboard');
      }
      loadCartFromBackend(parsedUser);
    } else {
      loadLocalCart();
    }
  }, []);

  const loadCartFromBackend = async (userData = user) => {
    try {
      if (!userData || !userData.email) return;

      const response = await cartAPI.getCart(userData.email);

      const cartItemsWithFullUrls = response.data.map(item => ({
        ...item,
        image: item.image?.startsWith('http')
          ? item.image
          : `http://localhost:8080/images/${item.image}`
      }));

      setCartItems(cartItemsWithFullUrls);
      localStorage.removeItem('localCart');
    } catch (error) {
      console.error('Error loading cart:', error);
    }
  };

  const loadLocalCart = () => {
    const localCart = localStorage.getItem('localCart');
    if (localCart) {
      setCartItems(JSON.parse(localCart));
    }
  };

  const saveLocalCart = (items) => {
    localStorage.setItem('localCart', JSON.stringify(items));
  };

  const goTo = (path, data = null) => {
    navigate(path, { state: data });
    window.scrollTo(0, 0);
  };

  const login = async (userData, token) => {
    setIsLoggedIn(true);
    setUser(userData);
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(userData));

    const localCart = localStorage.getItem('localCart');
    if (localCart) {
      try {
        const localItems = JSON.parse(localCart);
        if (localItems.length > 0) {
          await cartAPI.mergeCart(userData.email, localItems);
        }
      } catch (error) {
        console.error('Error merging cart:', error);
      }
    }

    const pendingItem = localStorage.getItem('pendingCartItem');
    if (pendingItem) {
      try {
        const { product, quantity } = JSON.parse(pendingItem);
        await cartAPI.addToCart(userData.email, product.id, quantity);
        localStorage.removeItem('pendingCartItem');
        alert('Product added to cart!');
      } catch (error) {
        console.error('Error adding pending item:', error);
      }
    }

    await loadCartFromBackend(userData);

    if (userData.role === 'ADMIN') {
      goTo('/admin-dashboard');
    } else {
      goTo('/');
    }
  };

  const logout = () => {
    setIsLoggedIn(false);
    setUser(null);
    setCartItems([]);
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    localStorage.removeItem('localCart');
    goTo('/');
  };

  const addToCart = async (product, quantity = 1) => {
    if (!isLoggedIn || !user?.email) {
      localStorage.setItem('pendingCartItem', JSON.stringify({ product, quantity }));
      alert('Please login to add items to cart');
      goTo('/login');
      return;
    }

    try {
      await cartAPI.addToCart(user.email, product.id, quantity);
      await loadCartFromBackend();
      alert('Product added to cart!');
    } catch (error) {
      console.error('Error adding to cart:', error);
      alert('Failed to add product to cart');
    }
  };

  const updateQuantity = async (itemId, change) => {
    try {
      const item = cartItems.find((i) => i.id === itemId);
      if (!item) return;

      const newQuantity = item.quantity + change;
      if (newQuantity < 1) {
        await removeItem(itemId);
        return;
      }

      await cartAPI.updateCart(user.email, itemId, newQuantity);
      await loadCartFromBackend();
    } catch (error) {
      console.error('Error updating quantity:', error);
      alert('Failed to update quantity');
    }
  };

  const removeItem = async (itemId) => {
    try {
      await cartAPI.removeFromCart(user.email, itemId);
      await loadCartFromBackend();
    } catch (error) {
      console.error('Error removing item:', error);
    }
  };

  const updateUserProfile = async (updatedData) => {
    try {
      const response = await userAPI.updateProfile(updatedData);
      const updatedUser = { ...user, ...response.data };
      setUser(updatedUser);
      localStorage.setItem('user', JSON.stringify(updatedUser));
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  };

  const isAdmin = user?.role === 'ADMIN';

  return (
    <Routes>

      <Route
        path="/"
        element={
          <HomePage
            navigate={goTo}
            cartItems={cartItems}
            isLoggedIn={isLoggedIn}
            user={user}
            logout={logout}
            addToCart={addToCart}
          />
        }
      />

      <Route path="/login" element={<LoginPage navigate={goTo} login={login} />} />
      <Route path="/register" element={<RegisterPage navigate={goTo} />} />

      <Route
        path="/all-products"
        element={
          <AllProductsPage
            navigate={goTo}
            addToCart={addToCart}
            cartItems={cartItems}
            isLoggedIn={isLoggedIn}
            user={user}
            logout={logout}
          />
        }
      />

      <Route
        path="/category/products"
        element={
          <CategoryProductsPage
            navigate={goTo}
            addToCart={addToCart}
            cartItems={cartItems}
            isLoggedIn={isLoggedIn}
            user={user}
            logout={logout}
          />
        }
      />

      <Route
        path="/product-detail"
        element={
          <ProductDetailPage
            navigate={goTo}
            addToCart={addToCart}
            cartItems={cartItems}
            isLoggedIn={isLoggedIn}
            user={user}
            logout={logout}
          />
        }
      />

      <Route
        path="/cart"
        element={
          <ShoppingCartPage
            navigate={goTo}
            cartItems={cartItems}
            updateQuantity={updateQuantity}
            removeItem={removeItem}
            isLoggedIn={isLoggedIn}
            user={user}
            logout={logout}
          />
        }
      />

      <Route
        path="/checkout"
        element={
          isLoggedIn ? (
            <CheckoutPage
              navigate={goTo}
              cartItems={cartItems}
              isLoggedIn={isLoggedIn}
              user={user}
              logout={logout}
              setCartItems={setCartItems}
            />
          ) : (
            <LoginPage navigate={goTo} login={login} />
          )
        }
      />

      <Route
        path="/profile"
        element={
          isLoggedIn ? (
            <ProfilePage
              navigate={goTo}
              user={user}
              isLoggedIn={isLoggedIn}
              logout={logout}
              updateUserProfile={updateUserProfile}
            />
          ) : (
            <LoginPage navigate={goTo} login={login} />
          )
        }
      />

      {/* ✅ ORDER HISTORY ROUTE */}
      <Route
        path="/orders"
        element={
          isLoggedIn ? (
            <OrderHistoryPage
              navigate={goTo}
              isLoggedIn={isLoggedIn}
              user={user}
              logout={logout}
            />
          ) : (
            <LoginPage navigate={goTo} login={login} />
          )
        }
      />

      <Route
        path="/customer-help"
        element={
          <CustomerHelpPage
            navigate={goTo}
            isLoggedIn={isLoggedIn}
            user={user}
            logout={logout}
          />
        }
      />

      <Route
        path="/admin-login"
        element={<AdminLoginPage navigate={goTo} login={login} />}
      />

      <Route
        path="/admin-dashboard"
        element={
          isAdmin ? (
            <AdminDashboard navigate={goTo} logout={logout} user={user} />
          ) : (
            <AdminLoginPage navigate={goTo} login={login} />
          )
        }
      />

      <Route
        path="/admin-products"
        element={
          isAdmin ? (
            <AdminProductManagement
              navigate={goTo}
              category={categoryData?.category}
            />
          ) : (
            <AdminLoginPage navigate={goTo} login={login} />
          )
        }
      />

      {/* ✅ ✅ NEW ADMIN ORDERS ROUTE */}
      <Route
        path="/admin-orders"
        element={
          isAdmin ? (
            <AdminOrderManagement />
          ) : (
            <AdminLoginPage navigate={goTo} login={login} />
          )
        }
      />

      <Route
        path="/admin-add-product"
        element={
          isAdmin ? (
            <AdminProductManagement navigate={goTo} category={null} />
          ) : (
            <AdminLoginPage navigate={goTo} login={login} />
          )
        }
      />

      <Route
        path="*"
        element={
          <HomePage
            navigate={goTo}
            cartItems={cartItems}
            isLoggedIn={isLoggedIn}
            user={user}
            logout={logout}
            addToCart={addToCart}
          />
        }
      />
      <Route path="/admin-returns" element={ isAdmin ? (  <AdminReturnManagement navigate={goTo} /> ) : ( <AdminLoginPage navigate={goTo} login={login} /> ) } />

    </Routes>
  );
}

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}

